<?php
/**

    Digiwallet module class for Zencart
    (C) Copyright Yellow Melon B.V. 2013

*/

define('FILENAME_TARGETPAY_TRANSACTIONS', 'targetpay_transactions.php');

define('TABLE_TARGETPAY_TRANSACTIONS', DB_PREFIX . 'digiwallet_transactions');
define('TABLE_TARGETPAY_DIRECTORY', DB_PREFIX . 'digiwallet_directory');
define('TABLE_TARGETPAY_REFUND', DB_PREFIX . 'digiwallet_refund');
