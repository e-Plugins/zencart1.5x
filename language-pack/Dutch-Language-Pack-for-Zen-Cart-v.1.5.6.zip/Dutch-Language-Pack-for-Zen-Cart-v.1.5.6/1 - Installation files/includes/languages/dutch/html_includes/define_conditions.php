<p><strong>Voorbeeldtekst algemene voorwaarden..</strong></p><p>Deze tekst is van de Paginadefenitie editor. Deze kunt u vinden onder Hulpmiddelen in het beheerpaneel.</p>
<p>Dit bestand staat in<code> /languages/dutch/html_includes/</code></p>
<p><strong>NB: Maak altijd een reservekopie van<code> /languages/dutch/html_includes/your_template</code></strong></p>