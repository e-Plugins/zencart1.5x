<?php
/**
 * @package payment_modules
 * @ Maintained by Zen4All (https://zen4all.nl)
 * @copyright Copyright 2003-2018 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Drbyte Sun Jan 7 21:30:21 2018 -0500 Modified in v1.5.6 $
 */

  define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE', 'Gratis bestelling');
  define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION', 'Alleen gebruiken voor het bestellen van volledig GRATIS PRODUCTEN zonder enige bijkomende kosten');
  define('MODULE_PAYMENT_FREECHARGER_TEXT_EMAIL_FOOTER', 'Gebruiken voor bestellen van gratis producten');
