<?php
/**
 * @package languageDefines Dutch Zen Cart Version 1.5.3
 * @ Maintained by Zen4All (https://zen4all.nl)
 * @copyright Copyright 2003-2011 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: freeshipper.php 18697 2011-05-04 14:35:20Z wilt $
 */

define('MODULE_SHIPPING_FREESHIPPER_TEXT_TITLE', 'Geen verzendkosten!');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_DESCRIPTION', 'GRATIS VERZENDEN');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_WAY', 'Geen verzendkosten');
