<?php
//
// @package languageDefines Dutch Zen Cart Version 1.5.3
// @ Maintained by Zen4All (https://zen4all.nl)
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// $Id: popup_search_help.php 2471 2005-11-29 01:14:18Z drbyte $
//

define('HEADING_SEARCH_HELP', 'Zoek Help');
define('TEXT_SEARCH_HELP', 'Zoektermen kunnen worden gescheiden met AND en/of OR voor specifiekere zoekresultaten.<br /><br />Microsoft AND muis zal bijvoorbeeld een resultaat weergeven waarin beide woorden in voorkomen. Doch voor muis OR toetsenbord zullen er resultaten worden weergegeven die beide of één van de zoekwoorden bevatten.<br /><br />Exact zoeken kan door de zoektermen in te sluiten in aanhalingstekens.<br /><br />Voor bijvoorbeeld "notebook computer" zullen alleen resultaten weergegeven worden waarin exact deze combinatie voorkomt .<br /><br />Haakjes kunnen worden gebruikt om de zoekresultaten verder te specificeren.<br /><br />Bijvoorbeeld Microsoft AND (keyboard OR muis OR "visual basic").');
define('TEXT_CLOSE_WINDOW', '<span class="pseudolink">Sluit venster</span> [x]');

?>