<?php
/**
 * @package admin
 * @ Maintained by Zen4All (https://zen4all.nl)
 * @copyright Copyright 2003-2018 Zen Cart Development Team
 * @author inspired from sales_report_graphs.php,v 0.01 2002/11/27 19:02:22 cwi Exp  Released under the GNU General Public License $
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Drbyte Mon Aug 7 23:27:01 2017 -0400 New in v1.5.6 $
 */

define('BOX_REPORTS_SALES_REPORT_GRAPHS', 'Sales Rapport met grafieken');
define('MONTH_TO_DATE', 'Deze maand');
